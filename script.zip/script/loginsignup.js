    let loginBtn = document.getElementById('loginBtn');
    let signupBtn = document.getElementById('signupBtn');
    let loginForm = document.getElementById('loginForm');
    let loggedInContainer = document.querySelector('.container');
    let loginSubmitForm = document.getElementById('logout1');
    let signupForm = document.getElementById("signupForm");
    let invalidMessage = document.getElementById("invalidMessage");
    invalidMessage.style.display = "none";
    loginBtn.addEventListener('click', function () {
        invalidMessage.style.display = "none";
        signupForm.style.display = "none";
        loginForm.style.display = 'block';
        loggedInContainer.style.display = 'none';
    });

    signupBtn.addEventListener('click', function () {
        loginForm.style.display = 'none';
        loggedInContainer.style.display = 'none';
        signupForm.style.display = "block";
        invalidMessage.style.display = "none";
    });
    let usernameInput = document.getElementById('username');
    let passwordInput = document.getElementById('password');
    loginSubmitForm.addEventListener('click', function (event) {
        event.preventDefault();

        // Check if the entered username and password are 'admin'
        
        console.log(usernameInput.value)
        if (usernameInput.value === 'admin' && passwordInput.value === 'admin') {
            // If the credentials match, show the logged-in container and hide the login form
            loggedInContainer.style.display = 'block';
            document.getElementById("logout1").style.display = 'none';
            invalidMessage.style.display = "none";
        } else {
            // If the credentials don't match, you can display an error message or take other actions
            console.log("Error");
            invalidMessage.style.display = "block";
            setTimeout(() => {
                invalidMessage.style.display = "none";
            }, 5000);
        }
    });

function logout1(){
    loggedInContainer.style.display = 'none';
    document.getElementById("logout1").style.display = 'block';
    usernameInput.value = "";
    passwordInput.value = "";
}